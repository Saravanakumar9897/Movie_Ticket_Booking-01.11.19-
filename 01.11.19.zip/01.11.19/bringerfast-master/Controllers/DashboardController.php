<?php
/**
 * Created by PhpStorm.
 * Author:Vishnu Vardhan G
 * Date: 31/10/19
 * Time: 1:09 AM
 */

namespace Controllers;


use Models\Dashboard;
use Request\Request;
use Throwable;

class DashboardController
{
    public function dashboardFetch(){
        try {
            $data = Dashboard::all();
            export('backend/dashboard/dashboard',$data);
        }catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}
?>