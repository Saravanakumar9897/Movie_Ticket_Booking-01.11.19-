<?php
/**
 * Created by PhpStorm.
 * Author : Banupriya
 * Editter:Vishnu Vardhan G
 * Date: 31/10/19
 * Time: 1:09 AM
 */
namespace Controllers;


use Models\ClassType;
use Request\Request;
use Throwable;

class ClassTypeController
{
    public function __construct()
    {
        auth('user'); //To authenticate right user 
    }

    public function classTypeIndex(){
        try {
            $classTypes = ClassType::all();// To fetch all record using ClassType model
            export('backend/class_types/view_all',$classTypes);//Export view data to appfunctions  
        }catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function classTypeForm(){
        try {
            export('backend/class_types/create_form',''); //To execute create form using export functions
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function classTypeStore(Request $request){
       try {
           $formData = $request->getBody();//To fetch form data using getBody() with request object 
           ClassType::insert($formData);
           redirect('/classTypeIndex');
       } catch (Throwable $e) {
           dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
       }
    }

    public function classTypeShow(Request $request){
        try {
            $formData = $request->getBody();
            $classType = ClassType::select($formData['class_type_id']);
            export('backend/class_types/show',$classType);
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function classTypeEditForm(Request $request){
        try {
            $formData = $request->getBody();
            $classType = ClassType::select($formData['class_type_id']);
            export('backend/class_types/edit_form',$classType);//To execute edit form data using select query
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function classTypeUpdate(Request $request){
       try {
           $formData = $request->getBody();
           ClassType::update($formData);//To execute update query 
           redirect('/classTypeIndex');
       } catch (Throwable $e) {
           dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
       }
    }

    public function classTypeDelete(Request $request){
        try {
            $formData = $request->getBody();
            ClassType::delete($formData['class_type_id']);//To delete single row of data using delete query
            redirect('/classTypeIndex');
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}
?>