-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `ticket_system` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ticket_system`;

DROP TABLE IF EXISTS `t_booking_details`;
CREATE TABLE `t_booking_details` (
  `booking_details_id` int(4) NOT NULL AUTO_INCREMENT,
  `r_payment_id` int(4) NOT NULL,
  `r_screen_shows_id` int(4) NOT NULL,
  `payment_type` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `r_snack_id` int(4) NOT NULL,
  `snacks_quantity` tinyint(4) NOT NULL,
  `seat_quantity` tinyint(4) NOT NULL,
  `snack_amount` float NOT NULL,
  `seat_amount` float NOT NULL,
  PRIMARY KEY (`booking_details_id`),
  KEY `r_payment_id` (`r_payment_id`),
  KEY `r_snack_id` (`r_snack_id`),
  KEY `r_screen_shows_id` (`r_screen_shows_id`),
  CONSTRAINT `t_booking_details_ibfk_1` FOREIGN KEY (`r_snack_id`) REFERENCES `t_snacks` (`snack_id`),
  CONSTRAINT `t_booking_details_ibfk_2` FOREIGN KEY (`r_payment_id`) REFERENCES `t_payments` (`payment_id`),
  CONSTRAINT `t_booking_details_ibfk_3` FOREIGN KEY (`r_screen_shows_id`) REFERENCES `t_screen_shows` (`screen_shows_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `t_booking_details` (`booking_details_id`, `r_payment_id`, `r_screen_shows_id`, `payment_type`, `r_snack_id`, `snacks_quantity`, `seat_quantity`, `snack_amount`, `seat_amount`) VALUES
(1,	1,	1,	'cash',	1,	4,	3,	120,	360);

DROP TABLE IF EXISTS `t_class_type`;
CREATE TABLE `t_class_type` (
  `class_type_id` int(4) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `class_status` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Y',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`class_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_class_type` (`class_type_id`, `class_name`, `class_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'I Class',	'1',	'2019-10-13 00:00:00',	'2019-10-30 11:47:02',	NULL),
(2,	'II Class',	'1',	'2019-10-13 00:00:00',	'2019-10-30 11:47:02',	NULL),
(3,	'III Class',	'1',	'2019-10-13 00:00:00',	'2019-10-30 11:47:02',	NULL);

DROP TABLE IF EXISTS `t_movie_categories`;
CREATE TABLE `t_movie_categories` (
  `movie_category_id` int(4) NOT NULL AUTO_INCREMENT,
  `movie_category_name` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`movie_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_movie_categories` (`movie_category_id`, `movie_category_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'tamil',	'2019-10-13 00:00:00',	NULL,	NULL),
(3,	'Malayalam',	NULL,	NULL,	NULL),
(4,	'Telungu',	NULL,	NULL,	NULL),
(5,	'English',	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `t_movies`;
CREATE TABLE `t_movies` (
  `movie_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_movie_category_id` int(11) NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `release_date` date NOT NULL,
  `actor` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `actress` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `producer` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `director` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `duration` time NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `banner_image` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `list_image` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`movie_id`),
  KEY `movie_category_id` (`r_movie_category_id`),
  CONSTRAINT `t_movies_ibfk_1` FOREIGN KEY (`r_movie_category_id`) REFERENCES `t_movie_categories` (`movie_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `t_movies` (`movie_id`, `r_movie_category_id`, `name`, `release_date`, `actor`, `actress`, `producer`, `director`, `duration`, `description`, `banner_image`, `list_image`) VALUES
(1,	4,	'Kaithi',	'2020-02-23',	'Karthick',	'Someone',	'producer',	'director',	'03:00:00',	'&#60;p&#62;kdfklsflwfnmlkd&#60;/p&#62;&#13;&#10;',	'http://localhost:8000/Assets/uploads/images/1572343949_maxresdefault.jpg',	'http://localhost:8000/Assets/uploads/images/1572343949_download.jpeg'),
(3,	1,	'JOKER',	'2019-04-25',	'JOAQUIN PHOENIX',	'ZAZIE BEETZ',	'BRADLEY COOPER',	'TODD PHILLIPS',	'03:15:00',	'&#60;p&#62;DESCRIPTION OF JOKER&#60;/p&#62;&#13;&#10;',	'http://localhost:8000/Assets/uploads/images/1572589547_4852322547_joker.jpg',	'http://localhost:8000/Assets/uploads/images/1572589547_8068532899_1572536015_5794156956_jokerlandscape.jpg'),
(4,	1,	'BIGIL',	'2019-10-25',	'Vijay',	'Nayandhara',	'KALPATHI S AGHORAM',	'ATLEE',	'02:45:00',	'&#60;p&#62;DESCRIPTION OF BIGIL.&#60;/p&#62;&#13;&#10;',	'http://localhost:8000/Assets/uploads/images/1572589675_6913894708_1572537228_6076650999_bigil_logo.jpg',	'http://localhost:8000/Assets/uploads/images/1572589675_2646344140_1572466385_2850754422_bigil_banner2.jpg'),
(5,	1,	'KAITHI',	'2019-10-25',	'KARTHI',	'ACTRESS',	'S.R.PRABJU',	'LOKESH KANAGARAJ',	'02:30:00',	'&#60;p&#62;DESCRIPTION OF KAITHI&#60;/p&#62;&#13;&#10;',	'http://localhost:8000/Assets/uploads/images/1572589756_1437042824_1572537412_8315836144_kaithi.jpg',	'http://localhost:8000/Assets/uploads/images/1572589756_7574440765_1572537412_3073133770_kaithi2.jpg'),
(6,	1,	'ASURAN',	'2019-10-25',	'DHANUSH',	'MANJU WARRIER',	'KALAIPPULI S.THANU',	'VETTRIMARAN',	'02:25:00',	'&#60;p&#62;DESCRIPTION OF ASURAN.&#60;/p&#62;&#13;&#10;',	'http://localhost:8000/Assets/uploads/images/1572589832_5254680342_1572538394_2709999403_asuran-et00092591-25-12-2018-12-56-55.jpg',	'http://localhost:8000/Assets/uploads/images/1572589832_4953607939_1572538394_8938715362_asuranland.jpg'),
(7,	5,	'TERMINATOR: DARK FATE',	'2019-10-12',	'ARNOD SCHWARZENEGGER',	'LINDA HAMILTON',	'JAMES CAMERON',	'TIM MILLER',	'02:00:00',	'&#60;p&#62;DESCRIPTION OF TERMINATOR:DARK FATE&#60;/p&#62;&#13;&#10;',	'http://localhost:8000/Assets/uploads/images/1572589921_9456219669_1572540707_8187438835_terminatorportrait.jpg',	'http://localhost:8000/Assets/uploads/images/1572589921_6780277400_1572540707_3261356984_terminatorland.jpg');

DROP TABLE IF EXISTS `t_payments`;
CREATE TABLE `t_payments` (
  `payment_id` int(4) NOT NULL AUTO_INCREMENT,
  `r_user_id` int(4) NOT NULL,
  `PNR_no` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `total_amount` double NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `customer_id` (`r_user_id`),
  CONSTRAINT `t_payments_ibfk_1` FOREIGN KEY (`r_user_id`) REFERENCES `t_users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `t_payments` (`payment_id`, `r_user_id`, `PNR_no`, `total_amount`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	2,	'DFG324',	500,	'2019-10-09 00:00:00',	NULL,	NULL),
(2,	3,	'TEYTCB965',	450,	'2019-10-09 00:00:00',	NULL,	NULL);

DROP TABLE IF EXISTS `t_roles`;
CREATE TABLE `t_roles` (
  `role_id` int(4) NOT NULL,
  `role_name` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_roles` (`role_id`, `role_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'superAdmin',	'2019-10-09 00:00:00',	NULL,	NULL),
(2,	'admin',	'2019-10-09 00:00:00',	NULL,	NULL),
(3,	'customer',	'2019-10-09 00:00:00',	NULL,	NULL);

DROP TABLE IF EXISTS `t_screen_classes`;
CREATE TABLE `t_screen_classes` (
  `screen_classes_id` int(4) NOT NULL AUTO_INCREMENT,
  `r_screen_id` int(4) NOT NULL,
  `r_class_id` int(4) NOT NULL,
  `r_seat_id` int(4) NOT NULL,
  PRIMARY KEY (`screen_classes_id`),
  KEY `screen_id` (`r_screen_id`),
  KEY `class_id` (`r_class_id`),
  KEY `r_seat_id` (`r_seat_id`),
  CONSTRAINT `t_screen_classes_ibfk_1` FOREIGN KEY (`r_screen_id`) REFERENCES `t_screens` (`screen_id`),
  CONSTRAINT `t_screen_classes_ibfk_2` FOREIGN KEY (`r_class_id`) REFERENCES `t_class_type` (`class_type_id`),
  CONSTRAINT `t_screen_classes_ibfk_3` FOREIGN KEY (`r_seat_id`) REFERENCES `t_seats` (`seat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_screen_classes` (`screen_classes_id`, `r_screen_id`, `r_class_id`, `r_seat_id`) VALUES
(1,	1,	1,	0),
(2,	1,	1,	0),
(3,	1,	1,	0);

DROP TABLE IF EXISTS `t_screen_shows`;
CREATE TABLE `t_screen_shows` (
  `screen_shows_id` int(4) NOT NULL AUTO_INCREMENT,
  `r_screen_classes_id` int(4) NOT NULL,
  `r_show_id` int(4) NOT NULL,
  `r_movie_id` int(4) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`screen_shows_id`),
  KEY `show_id` (`r_show_id`),
  KEY `movie_id` (`r_movie_id`),
  KEY `r_screen_classes_id` (`r_screen_classes_id`),
  CONSTRAINT `t_screen_shows_ibfk_3` FOREIGN KEY (`r_show_id`) REFERENCES `t_shows` (`show_id`),
  CONSTRAINT `t_screen_shows_ibfk_4` FOREIGN KEY (`r_movie_id`) REFERENCES `t_movies` (`movie_id`),
  CONSTRAINT `t_screen_shows_ibfk_5` FOREIGN KEY (`r_screen_classes_id`) REFERENCES `t_screen_classes` (`screen_classes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_screen_shows` (`screen_shows_id`, `r_screen_classes_id`, `r_show_id`, `r_movie_id`, `date_time`) VALUES
(1,	1,	1,	1,	'2019-10-13 09:42:00'),
(2,	1,	1,	1,	'2019-10-13 09:42:00'),
(3,	1,	1,	1,	'2019-10-13 09:42:00');

DROP TABLE IF EXISTS `t_screens`;
CREATE TABLE `t_screens` (
  `screen_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_theatre_id` int(11) NOT NULL,
  `screen_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `screen_status` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`screen_id`),
  KEY `theatre_id` (`r_theatre_id`),
  CONSTRAINT `t_screens_ibfk_1` FOREIGN KEY (`r_theatre_id`) REFERENCES `t_theatres` (`theatre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_screens` (`screen_id`, `r_theatre_id`, `screen_name`, `screen_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	'jflsadvdnv',	'1',	'2019-10-13 00:00:00',	NULL,	NULL),
(2,	1,	'fsljfls',	'1',	'2019-10-13 00:00:00',	NULL,	NULL),
(3,	1,	'fjwojfskldnf',	'1',	'2019-10-13 00:00:00',	NULL,	NULL),
(5,	7,	'temprory',	'1',	NULL,	NULL,	NULL),
(6,	7,	'UserInter',	'1',	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `t_seats`;
CREATE TABLE `t_seats` (
  `seat_id` int(4) NOT NULL AUTO_INCREMENT,
  `seat_category` varchar(5) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `number_of_seats` tinyint(4) NOT NULL,
  `seat_status` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`seat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_seats` (`seat_id`, `seat_category`, `number_of_seats`, `seat_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2,	'B',	0,	'1',	'2019-10-09 00:00:00',	NULL,	NULL),
(3,	'A',	5,	'1',	NULL,	NULL,	NULL),
(4,	'C',	6,	'1',	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `t_shows`;
CREATE TABLE `t_shows` (
  `show_id` int(4) NOT NULL AUTO_INCREMENT,
  `show_category` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `duration` time NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`show_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_shows` (`show_id`, `show_category`, `duration`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'morning show',	'02:50:50',	'2019-10-13 00:00:00',	NULL,	NULL),
(2,	'evening show',	'03:00:00',	'2019-10-13 00:00:00',	NULL,	NULL),
(3,	'night show',	'02:30:10',	'2019-10-13 00:00:00',	NULL,	NULL);

DROP TABLE IF EXISTS `t_snacks`;
CREATE TABLE `t_snacks` (
  `snack_id` int(4) NOT NULL AUTO_INCREMENT,
  `r_theatre_id` int(4) NOT NULL,
  `snack_code` varchar(20) NOT NULL,
  `snack_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `description` text NOT NULL,
  `price` double NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`snack_id`),
  KEY `t_id` (`r_theatre_id`),
  CONSTRAINT `t_snacks_ibfk_1` FOREIGN KEY (`r_theatre_id`) REFERENCES `t_theatres` (`theatre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_snacks` (`snack_id`, `r_theatre_id`, `snack_code`, `snack_name`, `description`, `price`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	'CBD324',	'mixur',	'asdf asdf adsf asdf asdf asdf asd fasd fas dfa sd',	200,	'2019-10-13 00:00:00',	NULL,	NULL);

DROP TABLE IF EXISTS `t_theatres`;
CREATE TABLE `t_theatres` (
  `theatre_id` int(4) NOT NULL AUTO_INCREMENT,
  `r_user_id` int(4) NOT NULL,
  `theatre_name` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `contact` varchar(15) NOT NULL,
  `theatre_status` char(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`theatre_id`),
  KEY `t_theatres_ibfk_1` (`r_user_id`),
  CONSTRAINT `t_theatres_ibfk_1` FOREIGN KEY (`r_user_id`) REFERENCES `t_users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_theatres` (`theatre_id`, `r_user_id`, `theatre_name`, `address`, `contact`, `theatre_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	'theatre one',	'valasaravakkam',	'8765432190',	'1',	'2019-10-13 00:00:00',	NULL,	NULL),
(2,	2,	'theatre two',	'nungampakkam',	'7654321901',	'1',	'2019-10-13 00:00:00',	NULL,	NULL),
(3,	3,	'theatre three',	'virugampakkam',	'6543216789',	'1',	'2019-10-13 00:00:00',	NULL,	NULL),
(4,	7,	'temp',	'qazxfrtghb',	'123456789',	'1',	NULL,	NULL,	NULL),
(5,	3,	'mejestic',	'kovilambakkam',	'987654389',	'1',	NULL,	NULL,	NULL),
(6,	3,	'mejestic',	'kovilambakkam',	'987654389',	'1',	NULL,	NULL,	NULL),
(7,	2,	'VisionImpossible',	'thuraipakkam',	'987656789',	'1',	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `t_users`;
CREATE TABLE `t_users` (
  `user_id` int(4) NOT NULL AUTO_INCREMENT,
  `r_role_id` int(4) NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mobile_number` bigint(20) NOT NULL,
  `status` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `r_role_id` (`r_role_id`),
  CONSTRAINT `t_users_ibfk_1` FOREIGN KEY (`r_role_id`) REFERENCES `t_roles` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `t_users` (`user_id`, `r_role_id`, `name`, `email`, `password`, `mobile_number`, `status`, `created_by`, `updated_at`, `deleted_at`) VALUES
(1,	1,	'superadmin',	'superadmin@ticket.com',	'12345678',	8987634569,	'1',	'2019-10-09 00:00:00',	NULL,	NULL),
(2,	2,	'admin',	'admin@admin.com',	'12345678',	987656789,	'1',	'2019-10-09 00:00:00',	NULL,	NULL),
(3,	2,	'saravana',	'saravana232@gmail.com',	'12345678',	987654389,	'1',	'2019-10-09 00:00:00',	NULL,	NULL),
(4,	3,	'Banupriya',	'banumca121@gmail.com',	'12345678',	12345678,	'1',	NULL,	NULL,	NULL),
(7,	2,	'vishnu vardhan G',	'vishnuvijay@gmail.com',	'12345678',	7397108948,	'1',	NULL,	NULL,	NULL);

-- 2019-11-01 09:01:47
