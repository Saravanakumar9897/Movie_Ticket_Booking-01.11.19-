<?php
/**
 * Created by PhpStorm.
 * Author : Banurpriya
 * Editter : Vishnu Vardhan G
 * Date: 24/10/19
 * Time: 12:58 AM
 */
namespace Models;

use Connection\DB;
use Throwable;

class Screen
{
    private $table = 't_screens';
    private $fields = ['screen_id','r_theatre_id','screen_name','screen_status'];

   
    public static function all(){ // To fetch all data in screen table
        if ($_SESSION['user']['role_name'] == 'superAdmin'){ // To authenticate super admin data using session variable
            try{
                $stmt = DB::getConnection()->prepare("SELECT * FROM t_screens INNER JOIN t_theatres 
                    ON t_screens.r_theatre_id = t_theatres.theatre_id");
                $stmt->execute();
                $AllRows = [];
                while ($row = $stmt->fetch()){
                    $AllRows[] = $row;
                }
                return $AllRows;
            } catch (Throwable $e){
                dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
            }
        }else if($_SESSION['user']['role_name'] == 'admin'){ // To authenticate  admin data using session variable
            try{
                $stmt = DB::getConnection()->prepare("SELECT * FROM t_screens as screens
                    INNER JOIN  t_theatres as theatres
                    ON screens.r_theatre_id = theatres.theatre_id WHERE theatres.r_user_id=:user_id");
                $stmt->execute([':user_id'=>$_SESSION['user']['user_id']]);
                $AllRows = [];
                while ($row = $stmt->fetch()){
                    $AllRows[] = $row;
                }
                return $AllRows;
            } catch (Throwable $e){
                dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
            }
        }
    }

    public static function insert($data){ // To insert data in screens table using insert query
        try{
            $sql = "INSERT INTO t_screens (r_theatre_id,screen_name,screen_status) 
                    VALUES (:r_theatre_id,:screen_name,:screen_status)";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([
                ':r_theatre_id'=>$data['screenTheatre'],
                ':screen_name'=>$data['screenName'],                
                ':screen_status'=>$data['screenStatus']
            ]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function select($screen_id){ // To select data in screens table using select query
        try{
            $stmt = DB::getConnection()->prepare(" 
              SELECT 
                  screens.r_theatre_id, 
                  screens.*,
                  theatres.* 
              FROM 
                  t_screens as screens
              INNER JOIN 
                  t_theatres as theatres
                  ON theatres.theatre_id = screens.r_theatre_id
              WHERE screen_id = :screen_id LIMIT 1"
            );
            $stmt->execute([':screen_id' => $screen_id]);
            return $stmt->fetch();
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function update($data){ //To update data in screens table using update query
        try{
            $sql = "UPDATE 
                        t_screens 
                    SET  
                        screen_name =:screen_name,                        
                        screen_status =:screen_status
                    WHERE 
                        screen_id =:screen_id
                    ";
            $stmt= DB::getConnection()->prepare($sql);
             $stmt->execute([
                ':screen_name'=>$data['screenName'],                
                ':screen_status'=>$data['screenStatus'],
                ':screen_id'=>$data['screenId']
            ]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function delete($data){ // To delete singlel row of data in screens table using delete query
        try{
            $sql = 'UPDATE
                        t_screens 
                    SET 
                        screen_status =:screen_status
                    WHERE 
                        screen_id = :screen_id';
            $q = DB::getConnection()->prepare($sql);
            $q->execute([':screen_id' => $data['screen_id'],':screen_status' => '0']);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}
?>