<?php
/**
 * Created by PhpStorm.
 * Author : Banupriya
 * Date: 31/10/19
 * Time: 3:05 AM
 */

namespace Models;

use Connection\DB;
use Throwable;
class Show
{
    private $table = 't_shows';
    private $fields = ['show_id','show_category','duration'];

    public static function all(){ //To fetch all data in shows table 
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_shows");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function insert($data){ //To insert data in shows table 
        try{
            $sql = "INSERT INTO t_shows (show_category,duration) VALUES (?,?)";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([
                $data['showName'],
                $data['showDuration'],
            ]);
            return true;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function select($show_id){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_shows WHERE show_id = :show_id LIMIT 1");
            $stmt->execute([':show_id' => $show_id]);
            return $stmt->fetch();
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function update($data){//To update data in shows table
        try{
            $sql = "UPDATE t_shows SET show_category=:show_category, duration=:duration WHERE show_id=:show_id";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([':show_category'=>$data['showName'],':duration'=>$data['showDuration'],':show_id'=>$data['showId']]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function delete($show_id){//To delete single row of data in shows table 
        try{
            $sql = 'DELETE FROM t_shows WHERE show_id = :show_id';
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute([':show_id' => $show_id]);
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}