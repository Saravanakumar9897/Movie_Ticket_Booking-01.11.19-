<?php
/**
 * Created by PhpStorm.
 * User: Vishnu Vardhan G
 * Date: 31/10/19
 * Time: 01:58 AM
 */

namespace Models;


use Connection\DB;
use PDOException;

class Dashboard
{
    public static function all(){
        if ($_SESSION['user']['role_name'] == 'superAdmin') { // To authenticate super admin to access some roles 
            try{
                $user_stmt = DB::getConnection()->prepare("SELECT count(user_id) as user_count FROM t_users");
                $user_stmt->execute();
                $user_count = [];
                while ($row = $user_stmt->fetch()){
                    $user_count[] = $row[0];
                }

                $theatre_stmt = DB::getConnection()->prepare("SELECT count(theatre_id) as theatre_count FROM t_theatres ");
                $theatre_stmt->execute();
                $theatre_count = [];
                while ($row = $theatre_stmt->fetch()){
                    $theatre_count[] = $row[0];
                }

                $screen_stmt = DB::getConnection()->prepare("SELECT count(screen_id) as screen_count FROM t_screens ");
                $screen_stmt->execute();
                $screen_count = [];
                while ($row = $screen_stmt->fetch()){
                    $screen_count[] = $row[0];
                }

                $movie_stmt = DB::getConnection()->prepare("SELECT count(movie_id) as movie_count FROM t_movies ");
                $movie_stmt->execute();
                $movie_count = [];
                while ($row = $movie_stmt->fetch()){
                    $movie_count[] = $row[0];
                }

                $role_stmt = DB::getConnection()->prepare("SELECT count(role_id) as role_count FROM t_roles ");
                $role_stmt->execute();
                $role_count = [];
                while ($row = $role_stmt->fetch()){
                    $role_count[] = $row[0];
                }

                $movie_category_stmt = DB::getConnection()->prepare("SELECT count(movie_category_id) as movie_category_count FROM t_movie_categories  ");
                $movie_category_stmt->execute();
                $movie_category_count = [];
                while ($row = $movie_category_stmt->fetch()){
                    $movie_category_count[] = $row[0];
                }

                $class_type_stmt = DB::getConnection()->prepare("SELECT count(class_type_id) as class_type_count FROM t_class_type ");
                $class_type_stmt->execute();
                $class_type_count = [];
                while ($row = $class_type_stmt->fetch()){
                    $class_type_count[] = $row[0];
                }

                return ['user_count'=>$user_count[0],'theatre_count'=>$theatre_count[0],'screen_count'=>$screen_count[0],'movie_count'=>$movie_count[0],'role_count'=>$role_count[0],'movie_category_count'=>$movie_category_count[0],'class_type_count'=>$class_type_count[0]];

            } catch (PDOException $e){
                echo "Error on Theatre all function :".$e->getMessage();
            }
        }else if ($_SESSION['user']['role_name'] == 'admin') { // To authenticate admin data to access some roles
            try{
                $user_stmt = DB::getConnection()->prepare("SELECT count(user_id) as user_count FROM t_users WHERE user_id=:user_id");
                $user_stmt->execute([':user_id'=>$_SESSION['user']['user_id']]);
                $user_count = [];
                while ($row = $user_stmt->fetch()){
                    $user_count[] = $row[0];
                }

                $theatre_stmt = DB::getConnection()->prepare("SELECT count(theatre_id) as theatre_count FROM t_theatres  WHERE r_user_id=:r_user_id");
                $theatre_stmt->execute([':r_user_id'=>$_SESSION['user']['user_id']]);
                $theatre_count = [];
                while ($row = $theatre_stmt->fetch()){
                    $theatre_count[] = $row[0];
                }

                $screen_stmt = DB::getConnection()->prepare("SELECT count(screen_id) as screen_count
                    FROM t_screens as screens
                    INNER JOIN  t_theatres as theatres
                    ON screens.r_theatre_id = theatres.r_user_id 
                    WHERE theatres.r_user_id=:r_user_id");
                $screen_stmt->execute([':r_user_id'=>$_SESSION['user']['user_id']]);
                $screen_count = [];
                while ($row = $screen_stmt->fetch()){
                    $screen_count[] = $row[0];
                }

                $movie_stmt = DB::getConnection()->prepare("SELECT count(movie_id) as movie_count FROM t_movies ");
                $movie_stmt->execute();
                $movie_count = [];
                while ($row = $movie_stmt->fetch()){
                    $movie_count[] = $row[0];
                }

                $role_stmt = DB::getConnection()->prepare("SELECT count(role_id) as role_count FROM t_roles WHERE role_name =:role_name ");
                $role_stmt->execute([':role_name'=>$_SESSION['user']['role_name']]);
                $role_count = [];
                while ($row = $role_stmt->fetch()){
                    $role_count[] = $row[0];
                }

                $movie_category_stmt = DB::getConnection()->prepare("SELECT count(movie_category_id) as movie_category_count FROM t_movie_categories ");
                $movie_category_stmt->execute();
                $movie_category_count = [];
                while ($row = $movie_category_stmt->fetch()){
                    $movie_category_count[] = $row[0];
                }

                $class_type_stmt = DB::getConnection()->prepare("SELECT count(class_type_id) as class_type_count FROM t_class_type ");
                $class_type_stmt->execute();
                $class_type_count = [];
                while ($row = $class_type_stmt->fetch()){
                    $class_type_count[] = $row[0];
                }

                return ['user_count'=>$user_count[0],'theatre_count'=>$theatre_count[0],'screen_count'=>$screen_count[0],'movie_count'=>$movie_count[0],'role_count'=>$role_count[0],'movie_category_count'=>$movie_category_count[0],'class_type_count'=>$class_type_count[0]];

            } catch (PDOException $e){
                echo "Error on Theatre all function :".$e->getMessage();
            }
        }

    }

}
?>