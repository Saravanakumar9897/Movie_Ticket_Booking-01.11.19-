<!DOCTYPE html>
<html lang="en">
<head>
    <?php view('backend/partial/head_links.php') ?>
</head>
<body class="app sidebar-mini">
    <?php view('backend/partial/nav_bar.php') ?>
<?php if($_SESSION['user']['role_name']=='superAdmin'){view('backend/partial/side_bar.php');}
    elseif ($_SESSION['user']['role_name']=='admin') {
        view('backend/partial/admin_side_bar.php');
    } ?>

<?php $dashboard_data =  import(); ?>

    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
                <p>Welcome   <?php echo $_SESSION['user']['role_name']; ?></p>
            </div>
            <ul class="app-breadcrumb breadcrumb">
                <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
                <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            </ul>
        </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <span class="pull-left">All Theatres</span>
                            <a href="<?php echo baseURL().'/newTheatreForm'; ?>" class="fa fa-plus pull-right text-success" title="Create New"></a>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <th>S.No</th>
                                    <th>Field Name</th>
                                    <th>Count</th>
                                    <th>Actions</th>
                                </thead>
                                <tbody>
                                    <?php $count = 1; foreach ($dashboard_data as $key=>$value){ ?>
                                        <tr>
                                            <td><?php echo $count; ?></td>
                                            <td><?php echo $key; ?></td>
                                            <td><?php echo $value; ?></td>
                                            <td>
                                                <?php $temp = explode('_', $key);
                                                if($count == 7){$temp[0]=$temp[0].'Type';} ?>
                                                <a href="<?php echo baseURL().'/'.$temp[0].'Index?theatre_id='.$value['theatre_id']; ?>"><i class="fa fa-eye text-primary" style="margin-right: 5%;"></i></a>
                                            </td>
                                        </tr>
                                    <?php $count++;} ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer">
                            <div class="row">
                                <div class="col-md-5"></div>
                                <div class="col-md-2 text-center">
                                    <a class="link pull-left"><< </a>
                                    1
                                    <a class="link pull-right">>> </a>
                                </div>
                                <div class="col-md-5">
                                    <span class="pull-right">No Of Record : <?php echo count($dashboard_data) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </main>
    <?php view('backend/partial/foot_links.php') ?>
</body>
</html>
