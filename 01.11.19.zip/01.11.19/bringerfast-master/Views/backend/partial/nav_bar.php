<!-- Navbar-->
<header class="app-header">
    <a class="app-header__logo" href="<?php echo baseURL().'/admin'; ?>"><?php echo constant('APP_NAME')?></a>
    <!-- Sidebar toggle button-->
    <a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
   
    <ul class="app-nav">        
        
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="<?php echo baseURL().'/adminLogout'; ?>"  aria-label="Open Profile Menu"><i class="fa fa-sign-out fa-lg text-center"> sign-out</i></a>
        </li>
    </ul>
</header>



