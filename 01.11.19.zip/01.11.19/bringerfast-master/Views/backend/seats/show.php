<!DOCTYPE html>
<html lang="en">
<head>
    <?php view('backend/partial/head_links.php') ?>
</head>
<body class="app sidebar-mini">
<?php view('backend/partial/nav_bar.php') ?>
<?php if($_SESSION['user']['role_name']=='superAdmin'){view('backend/partial/side_bar.php');}
    elseif ($_SESSION['user']['role_name']=='admin') {
        view('backend/partial/admin_side_bar.php');
    } ?>
<?php $seat = import() ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Seat</h1>
            <p>Show Seat</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">class type / show </a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <span class="pull-left">Show Seat</span>
                    <a href="<?php echo baseURL().'/seatForm'; ?>" class="fa fa-plus pull-right text-primary" title="New"></a>
                    <a href="<?php echo baseURL().'/seatEditForm?seat_id='.$seat['seat_id']; ?>" class="fa fa-pencil pull-right text-warning" title="Edit"></a>
                    <a href="<?php echo baseURL().'/seatIndex'; ?>" class="fa fa-list pull-right text-success" title="View All"></a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <input class="form-control" type="text" name="seatId" value="<?php echo $seat['seat_id'] ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <input class="form-control" type="text" name="seatName" value="<?php echo $seat['seat_name']; ?>" readonly>
                        </div>
                    </div><br>
                    <div class="row">                       
                        <div class="col-md-6">
                            <input class="form-control" type="text" name="seatStatus" value="<?php echo $seat['status']; ?>" readonly>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row"></div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php view('backend/partial/foot_links.php') ?>
</body>
</html>

