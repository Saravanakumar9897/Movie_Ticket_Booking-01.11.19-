<!DOCTYPE html>
<html lang="en">
<head>
    <?php view('backend/partial/head_links.php') ?>
</head>
<body class="app sidebar-mini">
<?php view('backend/partial/nav_bar.php') ?>
<?php if($_SESSION['user']['role_name']=='superAdmin'){view('backend/partial/side_bar.php');}
    elseif ($_SESSION['user']['role_name']=='admin') {
        view('backend/partial/admin_side_bar.php');
    } ?>
<?php $seat = import() ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i>Seats</h1>
            <p>Edit Seat</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">seat / edit </a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <span class="pull-left">Edit Seat</span>
                    <a href="<?php echo baseURL().'/seatIndex'; ?>" class="fa fa-list pull-right text-success" title="View All"></a>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo baseURL().'/seatUpdate' ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="hidden" name="seatId" value="<?php echo $seat['seat_id'] ?>">
                                <input class="form-control" type="text" name="seatName" value="<?php echo $seat['seat_name']; ?>" placeholder="Enter Name Of Seat" required>
                            </div>
                             <div class="col-md-6">                                
                                <input class="form-control" type="text" name="numberOfSeats" value="<?php echo $seat['number_of_seats']; ?>" placeholder="Enter Number of Seats" required>
                            </div>
                        </div><br>  
                        <div class="row"> 
                            <div class="col-md-6">                                
                                <input class="form-control" type="text" name="seatStatus" value="<?php echo $seat['seat_status']; ?>" placeholder="Enter Status Of Seat" required>
                            </div>                          
                            <div class="col-md-6">
                                <input class="form-control btn-primary" type="submit" value="UPDATE THIS SEAT">
                            </div>
                            <div class="col-md-6"></div>
                        </div>                       
                    </form>
                </div>
                <div class="card-footer">
                    <div class="row"></div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php view('backend/partial/foot_links.php') ?>
</body>
</html>

