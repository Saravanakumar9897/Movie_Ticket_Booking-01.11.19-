<!DOCTYPE html>
<html lang="en">
<head>
    <?php view('backend/partial/head_links.php') ?>
</head>
<body class="app sidebar-mini">
<?php view('backend/partial/nav_bar.php') ?>
<?php if($_SESSION['user']['role_name']=='superAdmin'){view('backend/partial/side_bar.php');}
    elseif ($_SESSION['user']['role_name']=='admin') {
        view('backend/partial/admin_side_bar.php');
    } ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i>Theatres</h1>
            <p> Add Theatre</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo baseURL().'/admin'; ?>"><i class="fa fa-home fa-lg"></i></a></li>
            <li class="breadcrumb-item"><a href="#">theatre / add </a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <span class="pull-left">Add Theatre</span>
                    <a href="<?php echo baseURL().'/theatreIndex'; ?>" class="fa fa-list pull-right text-success" title="View All"></a>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo baseURL().'/newTheatreUpdate' ?>">
                        <div class="row">
                            <div class="col-md-2">
                                <label for="adminname">Admin name:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" readonly="true" type="text" name="adminName" placeholder="<?php echo $_SESSION['user']['name']; ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label for="adminemail">E-mail:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" readonly="true" type="text" name="adminEmail" placeholder="<?php echo $_SESSION['user']['email']; ?>" required>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-2">
                                <label for="theatrephone">Phone No:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" readonly="true" type="phone" name="phoneNumber" placeholder="<?php echo $_SESSION['user']['mobile_number']; ?>" required>
                            </div>
                            <div class="col-md-2">
                                <label for="aadharnumber">Admin Status:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" readonly="true" type="phone" name="adminStatus" placeholder="<?php if($_SESSION['user']['status'] == 1){$status='active';}else{$status='inactive';} echo $status; ?>" required>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-2">
                                <label for="theatrename">Theatre name:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="theatreName" placeholder="Enter Name Of Theatre" required>
                            </div>
                            <div class="col-md-2">
                                <label for="theatrephone">Total Screen:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="number" name="screenNumber" placeholder="Enter total screen" required>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-2">
                                <label for="theatrelocation">Theatre Address:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="theatreLocation" placeholder="Enter the Address" required>
                            </div>
                            <div class="col-md-2">
                                <label for="comments">Comments:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="comments" placeholder="Enter your comments" required>
                            </div>
                        </div><br><br>
                        <div class="row">
                            <div class="col-md-3">
                                
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-2">
                                <a  class="form-control btn-primary text-center" href="<?php echo baseURL().'/admin'; ?>">Go Home</a>
                            </div>
                            <div class="col-md-2">
                                <input class="form-control btn-primary" type="submit" value="Submit">
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-3">
                                
                            </div>
                        </div><br>
                    </form>
                </div>
                <div class="card-footer">
                    <div class="row"></div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php view('backend/partial/foot_links.php') ?>
</body>
</html>

