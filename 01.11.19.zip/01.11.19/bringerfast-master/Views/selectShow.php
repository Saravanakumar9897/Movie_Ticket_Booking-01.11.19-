<!-- Author:Saravana kumar
Description: Selecting shows page
 -->

<?php if($_SESSION['user']['role_name']=='customer'){
		$movies= import();
		$moviename = $_REQUEST['Moviename'];
		}else{
			redirect('/admin');
		} 
?>


 <!DOCTYPE html>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Select Show</title>
 		<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- available cdn -->

	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/style.css">
  <link rel="stylesheet" type="text/css" href="../Assets/backend/css/style1.css">
	<link rel="stylesheet" type="text/javascript" href="../Assets/backend/js/selectseats.js">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	 <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
	  <!-- carousel link -->
	   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	

 </head>
 <body>
 	<div class="container-fluid">
 		<div class="row">
 			<nav class="navbar navbar-inverse navbar-static-top">
                  <!-- navbar starts here -->
       	 <div class="container-fluid">
          <div class="navbar-header">
              <a class="navbar-brand" href="#"><img src="../Assets/backend/images/logoct.png"></a>
              
          </div>
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="#">Home</a></li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Languages <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#" class="active">Tamil</a></li>
                <li><a href="#">English</a></li>
                <li><a href="#">Hindi</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Chennai <span class="caret"></span></a>
              <ul class="dropdown-menu">
                
                <li><a href="#">Vellore</a></li>
                <li><a href="#">kancheepuram</a></li>
              </ul>
            </li>
			      <li>
			      	<?php if($_SESSION['user']['role_name']=='customer'){ ?>
			      		<a href="<?php echo baseURL().'/adminLogout'?>">log-out</a>
			  		<?php }else{ ?>
			      		<a href="<?php echo baseURL().'/admin'?>">log-in</a>
			  		<?php } ?>
			  	  </li>
          </ul>
          
      </div>

    </nav>        <!-- navbar ends here  -->
    <form action="\seat">  
    <div class="row">
    	<div class="container text-center">
		    <h1><?php echo $moviename;?></h1>
		    <h4> Select your Date </h4>
		</div>
		<div class="container text-center">
			<input type="date" class="date-calendar" required>
		</div>
		<div class=" row text-center">
			<h3>Shows</h3>
		</div>
		
	</div>

	<div class="row">
		<div class="col-md-6 text-center">
			<h3>Rohini Silver Cinemas </h3>
		</div>
	
		<div class="col-md-6 text-left">
			<a href=""><input type="submit" value="Morning show (11.30 AM)"  class="button-show"></a>
			<a href=""><input type="submit" value="Afternoon show (02.30 PM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Evening show (06.30 PM)"  class="button-show" ></a>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 text-center">
			<h3>Kumaran Cinemas </h3>
		</div>
	
		<div class="col-md-6 text-left">
			<a href=""><input type="submit" value="Morning show (11.30 AM)"  class="button-show"></a>
			<a href=""><input type="submit" value="Afternoon show (02.30 PM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Evening show (06.30 PM)"  class="button-show"></a>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 text-center">
			<h3>Karunambiga Cinemas</h3>
		</div>
	
		<div class="col-md-6 text-left">
			<a href=""><input type="submit" value="Morning show (11.30 AM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Afternoon show (02.30 PM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Evening show (06.30 PM)" class="button-show" ></a>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 text-center">
			<h3> Rajeshwari Cinemas </h3>
		</div>
	
		<div class="col-md-6 text-left">
			<a href=""><input type="submit" value="Morning show (11.30 AM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Afternoon show (02.30 PM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Evening show (06.30 PM)"  class="button-show"></a>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 text-center">
			<h3>Woodlands Multiplex</h3>
		</div>
	
		<div class="col-md-6 text-left">
			<a href=""><input type="submit" value="Morning show (11.30 AM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Afternoon show (02.30 PM)" class="button-show" ></a>
			<a href=""><input type="submit" value="Evening show (06.30 PM)" class="button-show" ></a>
		</div>
	</div>
</form>




 	</div>
 </body>
 </html>