<!DOCTYPE html>
<html>
<head>
	<title>Movie Details</title>
</head>
<body>
	
</body>
</html>