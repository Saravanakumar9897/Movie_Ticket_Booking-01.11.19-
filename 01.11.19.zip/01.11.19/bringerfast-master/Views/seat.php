
<?php if($_SESSION['user']['role_name']=='customer'){
        $movies= import();
        $moviename = $_REQUEST['Moviename'];
        }else{
            redirect('/admin');
        } 
?>
<html>

<head>
    <title>
        Seat Layout
    </title>
    <link rel="stylesheet" type="text/css" href="<?php echo baseURL(); ?>/Views/bin/seatLayout/seatLayout.css">
    <script src="<?php echo baseURL(); ?>/Views/app/lib/jquery.js"></script>
    <script src="<?php echo baseURL(); ?>/Views/bin/seatLayout/seatLayout.min.js"></script>
    <style>
        body{
           background: #dedede;
        }
        .inputBox {
            width: 100%;
            height: 150px;
            margin: 30px 0px 10px 0px;
        }
        .seat-selection{
            border: 1px solid #e7e7e7;
            background: #f5f5f5;
            padding: 20px;
        }
    </style>
</head>

<body>
    <div style="margin-bottom:30px;">
        <textarea class="inputBox" style="display:none;">
    {
        "product_id": 46539040,
        "freeSeating": false,
        "tempTransId": "1ecae165f2d86315fea19963d0ded41a",
        "seatLayout": {
        "colAreas": {
            "Count": 2,
            "intMaxSeatId": 43,
            "intMinSeatId": 2,
            "objArea": [
            {
                "AreaDesc": "EXECUTIVE",
                "AreaCode": "0000000003",
                "AreaNum": "1",
                "HasCurrentOrder": true,
                "objRow": [
                {
                    "GridRowId": 1,
                    "PhyRowId": "A",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 5,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 6,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 7,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 37,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 38,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    }
                    ]
                },
                {
                    "GridRowId": 2,
                    "PhyRowId": "B",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    }
                    ]
                },
                {
                    "GridRowId": 3,
                    "PhyRowId": "C",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 27
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 28
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 29
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 30
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 31
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 32
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 33
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 34
                    }
                    ]
                },
                {
                    "GridRowId": 4,
                    "PhyRowId": "D",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 27
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 28
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 29
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 30
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 31
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 32
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 33
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 34
                    }
                    ]
                },
                {
                    "GridRowId": 5,
                    "PhyRowId": "E",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 27
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 28
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 29
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 30
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 31
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 32
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 33
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 34
                    }
                    ]
                },
                {
                    "GridRowId": 6,
                    "PhyRowId": "F",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 27
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 28
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 29
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 30
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 31
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 32
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 33
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 34
                    }
                    ]
                },
                {
                    "GridRowId": 7,
                    "PhyRowId": "G",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 27
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 28
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 29
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 30
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 31
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 32
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 33
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 34
                    }
                    ]
                },
                {
                    "GridRowId": 8,
                    "PhyRowId": "H",
                    "objSeat": [
                    {
                        "GridSeatNum": 1,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 2,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 27
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 28
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 29
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 30
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 31
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 32
                    },
                    {
                        "GridSeatNum": 41,
                        "SeatStatus": "0",
                        "seatNumber": 33
                    },
                    {
                        "GridSeatNum": 42,
                        "SeatStatus": "0",
                        "seatNumber": 34
                    }
                    ]
                },
                {
                    "GridRowId": 11,
                    "PhyRowId": "I",
                    "objSeat": [
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    }
                    ]
                },
                {
                    "GridRowId": 12,
                    "PhyRowId": "J",
                    "objSeat": [
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    }
                    ]
                },
                {
                    "GridRowId": 13,
                    "PhyRowId": "K",
                    "objSeat": [
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "1",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    }
                    ]
                },
                {
                    "GridRowId": 14,
                    "PhyRowId": "L",
                    "objSeat": [
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    }
                    ]
                },
                {
                    "GridRowId": 15,
                    "PhyRowId": "M",
                    "objSeat": [
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 12,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 13,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 14,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 15,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 30,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 31,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    }
                    ]
                }
                ]
            },
            {
                "AreaDesc": "SPECIAL",
                "AreaCode": "0000000002",
                "AreaNum": "2",
                "HasCurrentOrder": true,
                "objRow": [
                {
                    "GridRowId": 1,
                    "PhyRowId": "N",
                    "objSeat": [
                    {
                        "GridSeatNum": 3,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 4,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 5,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 6,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 7,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 21,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 22,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 23,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 25
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 26
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 27
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 28
                    },
                    {
                        "GridSeatNum": 37,
                        "SeatStatus": "0",
                        "seatNumber": 29
                    },
                    {
                        "GridSeatNum": 38,
                        "SeatStatus": "0",
                        "seatNumber": 30
                    },
                    {
                        "GridSeatNum": 39,
                        "SeatStatus": "0",
                        "seatNumber": 31
                    },
                    {
                        "GridSeatNum": 40,
                        "SeatStatus": "0",
                        "seatNumber": 32
                    }
                    ]
                },
                {
                    "GridRowId": 2,
                    "PhyRowId": "O",
                    "objSeat": [
                    {
                        "GridSeatNum": 7,
                        "SeatStatus": "0",
                        "seatNumber": 1
                    },
                    {
                        "GridSeatNum": 8,
                        "SeatStatus": "0",
                        "seatNumber": 2
                    },
                    {
                        "GridSeatNum": 9,
                        "SeatStatus": "0",
                        "seatNumber": 3
                    },
                    {
                        "GridSeatNum": 10,
                        "SeatStatus": "0",
                        "seatNumber": 4
                    },
                    {
                        "GridSeatNum": 11,
                        "SeatStatus": "0",
                        "seatNumber": 5
                    },
                    {
                        "GridSeatNum": 16,
                        "SeatStatus": "0",
                        "seatNumber": 6
                    },
                    {
                        "GridSeatNum": 17,
                        "SeatStatus": "0",
                        "seatNumber": 7
                    },
                    {
                        "GridSeatNum": 18,
                        "SeatStatus": "0",
                        "seatNumber": 8
                    },
                    {
                        "GridSeatNum": 19,
                        "SeatStatus": "0",
                        "seatNumber": 9
                    },
                    {
                        "GridSeatNum": 20,
                        "SeatStatus": "0",
                        "seatNumber": 10
                    },
                    {
                        "GridSeatNum": 21,
                        "SeatStatus": "0",
                        "seatNumber": 11
                    },
                    {
                        "GridSeatNum": 22,
                        "SeatStatus": "0",
                        "seatNumber": 12
                    },
                    {
                        "GridSeatNum": 23,
                        "SeatStatus": "0",
                        "seatNumber": 13
                    },
                    {
                        "GridSeatNum": 24,
                        "SeatStatus": "0",
                        "seatNumber": 14
                    },
                    {
                        "GridSeatNum": 25,
                        "SeatStatus": "0",
                        "seatNumber": 15
                    },
                    {
                        "GridSeatNum": 26,
                        "SeatStatus": "0",
                        "seatNumber": 16
                    },
                    {
                        "GridSeatNum": 27,
                        "SeatStatus": "0",
                        "seatNumber": 17
                    },
                    {
                        "GridSeatNum": 28,
                        "SeatStatus": "0",
                        "seatNumber": 18
                    },
                    {
                        "GridSeatNum": 29,
                        "SeatStatus": "0",
                        "seatNumber": 19
                    },
                    {
                        "GridSeatNum": 32,
                        "SeatStatus": "0",
                        "seatNumber": 20
                    },
                    {
                        "GridSeatNum": 33,
                        "SeatStatus": "0",
                        "seatNumber": 21
                    },
                    {
                        "GridSeatNum": 34,
                        "SeatStatus": "0",
                        "seatNumber": 22
                    },
                    {
                        "GridSeatNum": 35,
                        "SeatStatus": "0",
                        "seatNumber": 23
                    },
                    {
                        "GridSeatNum": 36,
                        "SeatStatus": "0",
                        "seatNumber": 24
                    }
                    ]
                }
                ]
            }
            ]
        }
        },
        "areas": [],
        "groupedSeats": []
    }
        </textarea>
        <br>
        <input type="text" class="nuberOfSeat" placeholder="Number of seats" value="0" />
        <button class="call-load-function">Load</button>
    </div>

    <div class="selectMove"></div>

    <script src="<?php echo baseURL(); ?>/Views/app/js/app.js"></script>
</body>

</html>
